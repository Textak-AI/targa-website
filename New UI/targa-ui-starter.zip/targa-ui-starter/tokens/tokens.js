/**
 * TARGA AI — Design Tokens (JavaScript)
 *
 * Mirrors tokens.css for runtime access from JS components.
 * Use this when you need tokens inside JavaScript logic
 * (e.g., chart colors, dynamic inline styles). For CSS,
 * always prefer the CSS variables from tokens.css.
 */

export const colors = {
  // Brand
  navy: '#1f476a',
  teal: '#0eb2af',
  gold: '#fbbf24',

  // Category tiers
  tier: {
    strategic: '#0eb2af',
    execution: '#db2777',
    action: '#fbbf24',
    measurement: '#1f476a',
  },

  // Status
  status: {
    success: '#059669',
    successBg: '#ecfdf5',
    warning: '#d97706',
    warningBg: '#fef3c7',
    danger: '#dc2626',
    dangerBg: '#fef2f2',
  },

  // Neutrals
  white: '#ffffff',
  bgPage: '#f4f6f8',
  bgSubtle: '#f4f7fa',
  bgInset: '#e6ecf2',
  border: '#d6dee6',
  borderSubtle: '#e6ecf2',

  text: {
    primary: '#1f476a',
    secondary: '#4a5868',
    muted: '#6b7a8a',
    faint: '#8b99a8',
  },

  // Tinted variants
  tealDark: '#076c69',
  tealBg: '#e6f7f7',
  tealBorder: '#b8e8e7',
  pinkDark: '#8a3560',
  navyLight: '#dde6ef',
};

export const fonts = {
  display: "'Space Grotesk', -apple-system, BlinkMacSystemFont, sans-serif",
  body: "'Inter', -apple-system, BlinkMacSystemFont, sans-serif",
};

export const textSizes = {
  xs: 12,
  sm: 13,
  base: 14,
  md: 15,
  lg: 17,
  xl: 19,
  '2xl': 22,
  '3xl': 26,
  '4xl': 32,
};

export const space = {
  1: 4,
  2: 8,
  3: 12,
  4: 16,
  5: 20,
  6: 24,
  8: 32,
  10: 40,
  12: 48,
};

export const radius = {
  pill: 4,
  input: 6,
  cardInner: 8,
  card: 10,
  container: 12,
  circle: 9999,
};
