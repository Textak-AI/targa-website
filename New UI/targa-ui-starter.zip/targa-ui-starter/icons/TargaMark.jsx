import React from 'react';
import { colors } from '../tokens/tokens';

/**
 * TargaMark — The TARGA brand triangle mark.
 *
 * Three variants:
 *   - "intelligence" (default): teal small triangle + navy large triangle.
 *     Use for TARGA Intelligence surfaces (insights, suggestions,
 *     pattern detection, AI-authored content markers).
 *   - "ask": gold small triangle + navy large triangle.
 *     Use for Ask TARGA conversational surfaces.
 *   - "on-dark": teal small triangle + white large triangle.
 *     Use on dark/navy backgrounds.
 *
 * When this mark appears, it should signal "TARGA is speaking or
 * acting here." Do not use as decoration.
 *
 * @param {Object} props
 * @param {number} [props.size=24]
 * @param {'intelligence' | 'ask' | 'on-dark'} [props.variant='intelligence']
 * @param {string} [props.className]
 * @param {React.CSSProperties} [props.style]
 * @returns {JSX.Element}
 *
 * @example
 *   <TargaMark size={16} />                          // Intelligence
 *   <TargaMark variant="ask" size={20} />            // Ask TARGA
 *   <TargaMark variant="on-dark" size={40} />        // On navy
 */
export function TargaMark({ size = 24, variant = 'intelligence', className, style }) {
  const smallTriangleFill =
    variant === 'ask' ? colors.gold : colors.teal;
  const largeTriangleFill =
    variant === 'on-dark' ? colors.white : colors.navy;

  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      className={className}
      style={style}
      aria-label="TARGA"
      role="img"
    >
      <polygon
        points="14.4 18.6 9.7 18.6 12 13.8"
        fill={smallTriangleFill}
      />
      <polygon
        points="23.5 23.9 19.4 23.9 12.1 8.7 4.7 24 0.5 24 9.8 4.7 11.4 1.5 12.1 0"
        fill={largeTriangleFill}
      />
    </svg>
  );
}
