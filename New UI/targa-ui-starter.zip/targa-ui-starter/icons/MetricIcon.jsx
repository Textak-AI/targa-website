import React from 'react';
import { colors } from '../tokens/tokens';

/**
 * MetricIcon — Represents a Metric (KPI) object.
 *
 * Visual: three ascending navy bars with a teal accent dot on
 * the tallest bar.
 * Tier color: measurement navy.
 *
 * @param {Object} props
 * @param {number} [props.size=24]
 * @param {string} [props.className]
 * @param {React.CSSProperties} [props.style]
 * @returns {JSX.Element}
 */
export function MetricIcon({ size = 24, className, style }) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      className={className}
      style={style}
      aria-label="Metric"
      role="img"
    >
      <rect x="3" y="14" width="4" height="7" rx="1" fill={colors.navy} fillOpacity="0.4" />
      <rect x="10" y="9" width="4" height="12" rx="1" fill={colors.navy} fillOpacity="0.7" />
      <rect x="17" y="3" width="4" height="18" rx="1" fill={colors.navy} />
      <circle cx="19" cy="4" r="1.5" fill={colors.teal} />
    </svg>
  );
}
