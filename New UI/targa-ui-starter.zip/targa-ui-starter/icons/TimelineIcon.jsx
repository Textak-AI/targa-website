import React from 'react';
import { colors } from '../tokens/tokens';

/**
 * TimelineIcon — Represents a Timeline or date-based object.
 *
 * Visual: analog clock face with a gold pivot dot at center.
 *
 * @param {Object} props
 * @param {number} [props.size=24]
 * @param {string} [props.className]
 * @param {React.CSSProperties} [props.style]
 * @returns {JSX.Element}
 */
export function TimelineIcon({ size = 24, className, style }) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      className={className}
      style={style}
      aria-label="Timeline"
      role="img"
    >
      <circle cx="12" cy="12" r="9" fill={colors.navy} fillOpacity="0.12" />
      <circle cx="12" cy="12" r="9" fill="none" stroke={colors.navy} strokeWidth="1.6" />
      <path
        d="M12 7 L12 12 L15 14"
        stroke={colors.navy}
        strokeWidth="1.8"
        strokeLinecap="round"
        strokeLinejoin="round"
        fill="none"
      />
      <circle cx="12" cy="12" r="1" fill={colors.gold} />
    </svg>
  );
}
