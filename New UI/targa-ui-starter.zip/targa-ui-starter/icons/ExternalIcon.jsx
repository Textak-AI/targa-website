import React from 'react';
import { colors } from '../tokens/tokens';

/**
 * ExternalIcon — Represents an external link to a resource
 * outside the TARGA platform (Google Docs, Confluence, etc.).
 *
 * Visual: teal-outlined frame with outgoing diagonal arrow.
 *
 * @param {Object} props
 * @param {number} [props.size=24]
 * @param {string} [props.className]
 * @param {React.CSSProperties} [props.style]
 * @returns {JSX.Element}
 */
export function ExternalIcon({ size = 24, className, style }) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      className={className}
      style={style}
      aria-label="External link"
      role="img"
    >
      <rect x="3" y="7" width="13" height="13" rx="2" fill={colors.teal} fillOpacity="0.18" />
      <rect
        x="3"
        y="7"
        width="13"
        height="13"
        rx="2"
        fill="none"
        stroke={colors.teal}
        strokeWidth="1.6"
      />
      <path
        d="M13 3 L21 3 L21 11"
        stroke={colors.teal}
        strokeWidth="1.8"
        strokeLinecap="round"
        strokeLinejoin="round"
        fill="none"
      />
      <path
        d="M13 11 L21 3"
        stroke={colors.teal}
        strokeWidth="1.8"
        strokeLinecap="round"
        fill="none"
      />
    </svg>
  );
}
