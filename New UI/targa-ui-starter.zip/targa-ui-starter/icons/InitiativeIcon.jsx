import React from 'react';

/**
 * InitiativeIcon — Represents an Initiative (formerly "Project") object.
 *
 * Visual: magenta container with lidded top (workstream metaphor).
 * Tier color: execution magenta (#db2777).
 *
 * @param {Object} props
 * @param {number} [props.size=24]
 * @param {string} [props.className]
 * @param {React.CSSProperties} [props.style]
 * @returns {JSX.Element}
 */
export function InitiativeIcon({ size = 24, className, style }) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      className={className}
      style={style}
      aria-label="Initiative"
      role="img"
    >
      <rect x="3" y="8" width="18" height="13" rx="2" fill="#db2777" fillOpacity="0.2" />
      <rect x="3" y="8" width="18" height="4" rx="2" fill="#db2777" />
      <rect x="7" y="4" width="10" height="5" rx="1.5" fill="#db2777" />
    </svg>
  );
}
