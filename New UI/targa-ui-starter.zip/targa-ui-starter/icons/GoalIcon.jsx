import React from 'react';
import { colors } from '../tokens/tokens';

/**
 * GoalIcon — Represents a Goal (formerly "Strategic Plan") object.
 *
 * Visual: nested teal triangle with a gold apex dot.
 * Tier color: teal (strategic).
 *
 * @param {Object} props
 * @param {number} [props.size=24] - Width/height in pixels
 * @param {string} [props.className]
 * @param {React.CSSProperties} [props.style]
 * @returns {JSX.Element}
 *
 * @example
 *   <GoalIcon size={16} />
 *   <GoalIcon size={40} style={{ marginRight: 8 }} />
 */
export function GoalIcon({ size = 24, className, style }) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      className={className}
      style={style}
      aria-label="Goal"
      role="img"
    >
      <path d="M12 3 L21 20 L3 20 Z" fill={colors.teal} fillOpacity="0.2" />
      <path d="M12 8 L18 18 L6 18 Z" fill={colors.teal} />
      <circle cx="12" cy="3" r="1.5" fill={colors.gold} />
    </svg>
  );
}
