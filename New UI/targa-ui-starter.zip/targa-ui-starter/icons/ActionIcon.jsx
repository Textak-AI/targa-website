import React from 'react';
import { colors } from '../tokens/tokens';

/**
 * ActionIcon — Represents an Action (task or decision) object.
 *
 * Visual: gold tinted circle with a navy play-triangle.
 * Tier color: action gold.
 *
 * @param {Object} props
 * @param {number} [props.size=24]
 * @param {string} [props.className]
 * @param {React.CSSProperties} [props.style]
 * @returns {JSX.Element}
 */
export function ActionIcon({ size = 24, className, style }) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      className={className}
      style={style}
      aria-label="Action"
      role="img"
    >
      <circle cx="12" cy="12" r="10" fill={colors.gold} fillOpacity="0.22" />
      <path d="M10 7 L16 12 L10 17 Z" fill={colors.navy} />
    </svg>
  );
}
