import React from 'react';
import {
  GoalIcon,
  InitiativeIcon,
  ActionIcon,
  MetricIcon,
  TimelineIcon,
  ExternalIcon,
  TargaMark,
  Avatar,
  StatusPill,
  ProgressBar,
  SourceLogo,
  colors,
  fonts,
} from '../index';

/**
 * ExampleUsage — Demonstrates all starter components in context.
 *
 * Not a production component. Use this file as a reference when
 * wiring up the starter into your codebase. Safe to delete
 * once your team is familiar with the API.
 */
export function ExampleUsage() {
  return (
    <div
      style={{
        padding: 32,
        background: colors.bgPage,
        minHeight: '100vh',
        fontFamily: fonts.body,
        color: colors.text.primary,
      }}
    >
      <h2 style={{ fontFamily: fonts.display, fontSize: 22, marginBottom: 24 }}>
        TARGA UI Starter — Reference
      </h2>

      {/* Icons row */}
      <Section title="Object type icons">
        <Row>
          <IconLabel label="Goal"><GoalIcon /></IconLabel>
          <IconLabel label="Initiative"><InitiativeIcon /></IconLabel>
          <IconLabel label="Action"><ActionIcon /></IconLabel>
          <IconLabel label="Metric"><MetricIcon /></IconLabel>
          <IconLabel label="Timeline"><TimelineIcon /></IconLabel>
          <IconLabel label="External"><ExternalIcon /></IconLabel>
        </Row>
      </Section>

      {/* TARGA mark variants */}
      <Section title="TARGA brand mark">
        <Row>
          <IconLabel label="Intelligence"><TargaMark size={32} /></IconLabel>
          <IconLabel label="Ask"><TargaMark size={32} variant="ask" /></IconLabel>
          <div
            style={{
              background: colors.navy,
              padding: 12,
              borderRadius: 10,
              display: 'inline-flex',
              alignItems: 'center',
              justifyContent: 'center',
            }}
          >
            <TargaMark size={32} variant="on-dark" />
          </div>
        </Row>
      </Section>

      {/* Avatars */}
      <Section title="Avatars">
        <Row>
          <Avatar initials="JT" size={36} />
          <Avatar initials="KM" size={36} bg={colors.teal} fg="#fff" />
          <Avatar initials="MS" size={36} bg={colors.status.danger} fg="#fff" />
          <Avatar initials="SD" size={36} bg={colors.navy} fg="#fff" />
        </Row>
      </Section>

      {/* Status pills */}
      <Section title="Status pills">
        <Row>
          <StatusPill variant="success">ON TRACK</StatusPill>
          <StatusPill variant="warning">AT RISK</StatusPill>
          <StatusPill variant="danger">BLOCKER</StatusPill>
          <StatusPill variant="navy">OPERATIONAL</StatusPill>
          <StatusPill variant="teal">Q1 2026</StatusPill>
        </Row>
      </Section>

      {/* Progress bars */}
      <Section title="Progress bars">
        <div style={{ maxWidth: 400, display: 'flex', flexDirection: 'column', gap: 16 }}>
          <div>
            <Label>On track — 68%</Label>
            <ProgressBar pct={68} height={5} />
          </div>
          <div>
            <Label>Behind — 31%</Label>
            <ProgressBar pct={31} height={5} color={colors.status.warning} />
          </div>
          <div>
            <Label>Critical — 15%</Label>
            <ProgressBar pct={15} height={5} color={colors.status.danger} />
          </div>
        </div>
      </Section>

      {/* Source logos */}
      <Section title="Source system logos">
        <Row>
          <IconLabel label="NetSuite"><SourceLogo source="netsuite" size={28} /></IconLabel>
          <IconLabel label="SAP"><SourceLogo source="sap" size={28} /></IconLabel>
          <IconLabel label="Salesforce"><SourceLogo source="sf" size={28} /></IconLabel>
          <IconLabel label="Google Sheets"><SourceLogo source="gs" size={28} /></IconLabel>
          <IconLabel label="Confluence"><SourceLogo source="conf" size={28} /></IconLabel>
        </Row>
      </Section>

      {/* Composed example */}
      <Section title="Example composition — Goal row">
        <div
          style={{
            background: colors.white,
            border: `1px solid ${colors.border}`,
            borderRadius: 10,
            padding: '18px 22px',
            maxWidth: 560,
          }}
        >
          <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 10 }}>
            <GoalIcon size={14} />
            <div style={{ flex: 1, fontSize: 15, fontWeight: 500 }}>
              Expand gross margin by 300bps
            </div>
            <Avatar initials="JT" size={24} />
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 16, marginBottom: 10 }}>
            <div style={{ display: 'flex', alignItems: 'baseline', gap: 4 }}>
              <span style={{ fontFamily: fonts.display, fontSize: 18, fontWeight: 500 }}>62%</span>
              <span style={{ fontSize: 12, color: colors.text.muted }}>progress</span>
            </div>
            <div style={{ width: 1, height: 14, background: colors.border }} />
            <div style={{ display: 'flex', alignItems: 'baseline', gap: 4 }}>
              <span style={{ fontFamily: fonts.display, fontSize: 15, fontWeight: 500 }}>$24M</span>
            </div>
            <div style={{ marginLeft: 'auto', display: 'flex', gap: 5 }}>
              <StatusPill variant="success">ON TRACK</StatusPill>
            </div>
          </div>
          <ProgressBar pct={62} height={4} />
        </div>
      </Section>
    </div>
  );
}

function Section({ title, children }) {
  return (
    <div style={{ marginBottom: 32 }}>
      <div
        style={{
          fontSize: 12,
          fontWeight: 500,
          letterSpacing: 1.2,
          color: colors.tealDark,
          textTransform: 'uppercase',
          marginBottom: 14,
        }}
      >
        {title}
      </div>
      {children}
    </div>
  );
}

function Row({ children }) {
  return (
    <div style={{ display: 'flex', gap: 20, alignItems: 'center', flexWrap: 'wrap' }}>
      {children}
    </div>
  );
}

function IconLabel({ label, children }) {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 6 }}>
      <div
        style={{
          background: colors.white,
          border: `1px solid ${colors.border}`,
          borderRadius: 10,
          padding: 14,
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          width: 56,
          height: 56,
        }}
      >
        {children}
      </div>
      <div style={{ fontSize: 12, color: colors.text.muted }}>{label}</div>
    </div>
  );
}

function Label({ children }) {
  return (
    <div style={{ fontSize: 12, color: colors.text.muted, marginBottom: 6 }}>{children}</div>
  );
}
