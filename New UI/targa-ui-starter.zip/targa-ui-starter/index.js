/**
 * TARGA UI Starter — Public API
 *
 * Import what you need from the package root:
 *
 *   import {
 *     GoalIcon, InitiativeIcon, ActionIcon,
 *     MetricIcon, TimelineIcon, ExternalIcon,
 *     TargaMark,
 *     Avatar, StatusPill, ProgressBar, SourceLogo,
 *     colors, fonts, textSizes, space, radius,
 *   } from 'targa-ui-starter';
 */

// Icons
export { GoalIcon } from './icons/GoalIcon';
export { InitiativeIcon } from './icons/InitiativeIcon';
export { ActionIcon } from './icons/ActionIcon';
export { MetricIcon } from './icons/MetricIcon';
export { TimelineIcon } from './icons/TimelineIcon';
export { ExternalIcon } from './icons/ExternalIcon';
export { TargaMark } from './icons/TargaMark';

// Primitives
export { Avatar } from './primitives/Avatar';
export { StatusPill } from './primitives/StatusPill';
export { ProgressBar } from './primitives/ProgressBar';
export { SourceLogo } from './primitives/SourceLogo';

// Tokens
export { colors, fonts, textSizes, space, radius } from './tokens/tokens';
