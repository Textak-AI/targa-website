import React from 'react';
import { colors } from '../tokens/tokens';

/**
 * StatusPill — Small color-coded badge for status indicators.
 *
 * Use sparingly — one or two per row maximum. Too many pills
 * in a single view defeats their purpose as attention markers.
 *
 * Variants:
 *   - "success" (green): On Track, Resolved, Operational
 *   - "warning" (amber): At Risk, Behind, Risk
 *   - "danger" (red): Blocker, Overdue
 *   - "navy": Category tags (Operational, Q1 2026)
 *   - "teal": Period markers, neutral status
 *
 * @param {Object} props
 * @param {'success' | 'warning' | 'danger' | 'navy' | 'teal'} [props.variant='success']
 * @param {React.ReactNode} props.children - Pill label (use UPPERCASE)
 * @param {boolean} [props.hidden=false] - Animated fade-out (keeps in DOM)
 * @returns {JSX.Element}
 *
 * @example
 *   <StatusPill variant="success">ON TRACK</StatusPill>
 *   <StatusPill variant="danger">BLOCKER</StatusPill>
 *   <StatusPill variant="warning">▵ RISK</StatusPill>
 */
export function StatusPill({ variant = 'success', children, hidden = false }) {
  const palette = {
    success: { color: colors.status.success, background: colors.status.successBg },
    warning: { color: colors.status.warning, background: colors.status.warningBg },
    danger: { color: colors.status.danger, background: colors.status.dangerBg },
    navy: { color: colors.navy, background: colors.navyLight },
    teal: { color: colors.tealDark, background: colors.tealBg },
  }[variant] || { color: colors.status.success, background: colors.status.successBg };

  return (
    <span
      style={{
        fontSize: 12,
        fontWeight: 500,
        padding: '3px 8px',
        borderRadius: 4,
        letterSpacing: 0.3,
        whiteSpace: 'nowrap',
        opacity: hidden ? 0 : 1,
        transform: hidden ? 'scale(0.8)' : 'scale(1)',
        transition: 'opacity 0.8s, transform 0.8s',
        color: palette.color,
        background: palette.background,
        fontFamily: "'Inter', -apple-system, sans-serif",
      }}
    >
      {children}
    </span>
  );
}
