import React from 'react';
import { colors } from '../tokens/tokens';

/**
 * Avatar — Circular initials badge for person identification.
 *
 * Joe Thompson's avatar always uses gold background with navy
 * text. All other team members use their assigned role color:
 *   - Kyle Moyer (KM): teal + white
 *   - Mark Sternberger (MS): red + white
 *   - Sarah Darlington (SD): navy + white
 *   - Bill Adams (BA): navy + white
 *
 * For generic avatars, pass explicit bg and fg colors.
 *
 * @param {Object} props
 * @param {string} props.initials - 1-3 character initials (e.g., "JT")
 * @param {number} [props.size=24] - Diameter in pixels
 * @param {string} [props.bg] - Background color hex (default: gold)
 * @param {string} [props.fg] - Foreground (text) color hex (default: navy)
 * @returns {JSX.Element}
 *
 * @example
 *   <Avatar initials="JT" size={28} />
 *   <Avatar initials="KM" size={20} bg="#0eb2af" fg="#fff" />
 */
export function Avatar({ initials, size = 24, bg = colors.gold, fg = colors.navy }) {
  return (
    <div
      style={{
        width: size,
        height: size,
        borderRadius: '50%',
        background: bg,
        color: fg,
        fontSize: Math.round(size * 0.43),
        fontWeight: 600,
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        flexShrink: 0,
        fontFamily: "'Inter', -apple-system, sans-serif",
        lineHeight: 1,
      }}
      aria-label={`Avatar for ${initials}`}
    >
      {initials}
    </div>
  );
}
