import React from 'react';
import { colors } from '../tokens/tokens';

/**
 * ProgressBar — Horizontal fill bar with smooth-transition animation.
 *
 * Heights follow a scale:
 *   - 3px: Thin variant (dense lists, metric cards)
 *   - 5px: Standard (default for most cards)
 *   - 6-8px: Prominent (hero cards, focal goal card)
 *
 * Fill color should match the tier or status being communicated.
 *
 * @param {Object} props
 * @param {number} props.pct - Percentage 0-100
 * @param {number} [props.height=5] - Bar height in pixels
 * @param {string} [props.color] - Fill color hex (default: teal)
 * @returns {JSX.Element}
 *
 * @example
 *   <ProgressBar pct={68} />
 *   <ProgressBar pct={31} color="#d97706" height={6} />
 */
export function ProgressBar({ pct, height = 5, color = colors.teal }) {
  const clamped = Math.max(0, Math.min(100, pct));

  return (
    <div
      style={{
        height,
        background: colors.bgInset,
        borderRadius: 2,
        overflow: 'hidden',
      }}
      role="progressbar"
      aria-valuenow={clamped}
      aria-valuemin={0}
      aria-valuemax={100}
    >
      <div
        style={{
          width: `${clamped}%`,
          height: '100%',
          background: color,
          transition: 'width 1.4s cubic-bezier(0.4, 0, 0.2, 1)',
        }}
      />
    </div>
  );
}
