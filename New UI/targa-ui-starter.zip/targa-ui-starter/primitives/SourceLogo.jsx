import React from 'react';

/**
 * SourceLogo — Colored chip badge for external source systems.
 *
 * Used inside metric cards to identify where the number came from
 * (NetSuite, SAP, Salesforce, Google Sheets, Confluence), and in
 * external-link rows.
 *
 * These are simplified brand-evoking glyphs for UI chip display,
 * not official company logos. For customer-facing materials that
 * require trademark accuracy, replace with licensed SVG marks.
 *
 * Known source keys:
 *   - "netsuite": Blue "N"
 *   - "sap":      Blue "SAP"
 *   - "sf":       Cyan "sf" (Salesforce)
 *   - "gs":       Green "G" (Google Sheets)
 *   - "conf":     Blue "C" (Confluence)
 *
 * Extend the map below as new integrations come online.
 *
 * @param {Object} props
 * @param {string} props.source - One of the known source keys
 * @param {number} [props.size=18] - Chip size in pixels
 * @returns {JSX.Element}
 *
 * @example
 *   <SourceLogo source="netsuite" />
 *   <SourceLogo source="sf" size={14} />
 */
export function SourceLogo({ source, size = 18 }) {
  const map = {
    netsuite: { bg: '#125ca4', fg: '#fff', text: 'N' },
    sap: { bg: '#0070c0', fg: '#fff', text: 'SAP' },
    sf: { bg: '#00a1e0', fg: '#fff', text: 'sf' },
    gs: { bg: '#0f9d58', fg: '#fff', text: 'G' },
    conf: { bg: '#0052cc', fg: '#fff', text: 'C' },
  };
  const config = map[source] || map.netsuite;

  const fontSize = config.text.length > 1 ? size * 0.4 : size * 0.55;

  return (
    <div
      style={{
        width: size,
        height: size,
        borderRadius: 4,
        background: config.bg,
        color: config.fg,
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        fontSize,
        fontWeight: 700,
        flexShrink: 0,
        letterSpacing: config.text.length > 1 ? '-0.03em' : '0',
        fontFamily: "'Inter', -apple-system, sans-serif",
        lineHeight: 1,
      }}
      aria-label={`${source} logo`}
    >
      {config.text}
    </div>
  );
}
